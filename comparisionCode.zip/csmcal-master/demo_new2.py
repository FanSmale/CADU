import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from query_strategies.uncertainty_margin import UncertaintyMargin
from query_strategies.uncertainty_entropy import UncertaintyEntropy
from query_strategies.active_learning_with_cost_embedding import ALCE
from query_strategies.maximum_expected_cost import MEC
from query_strategies.cost_weighted_minimum_margin import CWMM
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC
import sys
sys.path.append('/Users/wuyanxue/Desktop/csmcal-master')

# set random seed
np.random.seed(1)

#dss = ["banana", "credit6000_126", "german", "image", "jain", "spambase", "twonorm", 
#"heart", "sonar", "thyroid", "ionosphere_real", "problem4","allaml", "arcene", "madelon"]

#dss = ['banana', 'credit6000_126', 'jain', 'spambase', 'sonar', 'allaml', 'arcene', 'madelon', 'ionosphere_real', 'thyoid', 'german', 'heart']
dss = ['allaml', 'arcene', 'banana', 'credit6000', 'german', 'heart', 'ionosphere_real', 'jain', 'madelon', 'sonar', 'spambase', 'thyroid']
steps = [1, 5, 30, 50, 5, 3, 3, 3, 40, 4, 25, 3]
numIterative = [20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]

for i in xrange(len(dss)):
    f1 = open('results.txt', 'a+')
    ds = dss[i]
    step = steps[i]
    numExperiment = numIterative[i]
    print 'data: ', ds
    print 'step: ', str(step)
    print 'numExperiment: ', str(numExperiment)
    f1.writelines(['data: ', ds, ', step: ', str(step), ', numIt: ', str(numExperiment), '\n'])
    # load
    x_data = np.loadtxt('data/'+ds+'.x', dtype=float)
    y_data = np.loadtxt('data/'+ds+'.y', dtype=int)

    cost_mat = np.array([[0, 4], [2, 0]]) # cost matrix
    N = x_data.shape[0] # number of instances


    def shuffle_data():
        idx = np.arange(N)
        np.random.shuffle(idx)
        x_pool = x_data[idx]
        y_pool = y_data[idx]
        unique, counts = np.unique(y_data, return_counts=True)
        # sample initial labeled instances
        idx_lbl = np.zeros((y_pool.shape[0], ), dtype=bool)
        for i in xrange(len(unique)):
            idx_lbl[np.random.choice(np.where(y_pool==(i+1))[0])] = True
        return x_pool, y_pool, idx_lbl
    
    # run several experiments
    sys.stderr.write('runing ')
    total_results = np.zeros((3, numExperiment))
            
    # Repeat the experiment
    for repeat in xrange(5):

        x_pool, y_pool, idx_lbl = shuffle_data()
        models = [ALCE(x_pool, y_pool*idx_lbl, cost_mat),
            CWMM(x_pool, y_pool*idx_lbl, cost_mat),
            MEC(x_pool, y_pool*idx_lbl, cost_mat)]

        # for recording rewards and actions
        results = np.zeros((len(models), numExperiment))
        idx_lbls = np.repeat(idx_lbl[:, None], len(models) ,axis=1)
        #print idx_lbls.shape

        for j, model in enumerate(models):
    
            for nq in xrange(numExperiment):
                for qNum in xrange(step):
                    q = model.query()
                    model.update(q, y_pool[q])
                    idx_lbls[q, j] = True
                clf = OneVsRestClassifier(SVC())
                clf.fit(x_pool[idx_lbls[:, j]], y_pool[idx_lbls[:, j]])
                p_test = clf.predict(x_pool[idx_lbls[:, j] == False])
                # sum of cost, which contains misclassification cost and teacher cost
                results[j, nq] = np.sum([cost_mat[y - 1, p - 1] for y, p in zip(y_pool[idx_lbls[:, j] == False], p_test)]) + (nq + 1) * step + 2
                results[j, nq] /= y_pool.shape[0]
        total_results += results
        sys.stderr.write('#')
        
    sys.stderr.write('Over\n')
    print total_results / 5
    f1.writelines([str(total_results / 5), '\n'])
    f1.close()