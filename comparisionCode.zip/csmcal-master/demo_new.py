import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from query_strategies.uncertainty_margin import UncertaintyMargin
from query_strategies.uncertainty_entropy import UncertaintyEntropy
from query_strategies.active_learning_with_cost_embedding import ALCE
from query_strategies.maximum_expected_cost import MEC
from query_strategies.cost_weighted_minimum_margin import CWMM
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC
import sys
sys.path.append('/Users/wuyanxue/Desktop/csmcal-master')

# set random seed
np.random.seed(1)

dss = ["banana", "credit6000_126", "german", "image", "jain", "spambase", "twonorm", 
"heart", "sonar", "thyroid", "ionosphere_real", "problem4","allaml", "arcene", "madelon"]
ds = dss[0]
Qs = [600, 897, 91, 170, 41, 411, 441, 55, 63, 45, 48, 215, 8, 61, 626]
Q = Qs[0] # number of queries
print 'ds:' + ds
print 'Queried:' + str(Q)

# load
x_data = np.loadtxt('data/'+ds+'.x', dtype=float)
y_data = np.loadtxt('data/'+ds+'.y', dtype=int)

cost_mat = np.array([[0, 4], [2, 0]]) # cost matrix
N = x_data.shape[0] # number of instances


def shuffle_data():
    idx = np.arange(N)
    np.random.shuffle(idx)
    x_pool = x_data[idx]
    y_pool = y_data[idx]
    unique, counts = np.unique(y_data, return_counts=True)
    # sample initial labeled instances
    idx_lbl = np.zeros((y_pool.shape[0], ), dtype=bool)
    for i in xrange(len(unique)):
        idx_lbl[np.random.choice(np.where(y_pool==(i+1))[0])] = True
    return x_pool, y_pool, idx_lbl

total_results = np.zeros((3, ))

# run several experiments
sys.stderr.write('total  ###\n')
sys.stderr.write('runing ')
num_repeat = 1
for i in xrange(num_repeat):
    # shuffle dataset
    x_pool, y_pool, idx_lbl = shuffle_data()
    models = [ALCE(x_pool, y_pool*idx_lbl, cost_mat),
        CWMM(x_pool, y_pool*idx_lbl, cost_mat),
        MEC(x_pool, y_pool*idx_lbl, cost_mat)]
    
    # for recording rewards and actions
    results = np.zeros((len(models), ))
    idx_lbls = np.repeat(idx_lbl[:, None], len(models) ,axis=1)
    #print idx_lbls.shape
    
    for j, model in enumerate(models):
        for nq in xrange(Q):
            q = model.query()
            model.update(q, y_pool[q])
            idx_lbls[q, j] = True
    for j in xrange(len(models)):
        clf = OneVsRestClassifier(SVC())
        clf.fit(x_pool[idx_lbls[:, j]], y_pool[idx_lbls[:, j]])
        p_test = clf.predict(x_pool[idx_lbls[:, j] == False])
        # sum of cost, which contains misclassification cost and teacher cost
        results[j] = np.sum([cost_mat[y-1, p-1] for y, p in zip(y_pool[idx_lbls[:, j] == False], p_test)]) + Q + 2
        results[j] /= y_pool.shape[0]
            
    # ipdb.set_trace()
    # print 1

    
    total_results += results
    sys.stderr.write('#')

sys.stderr.write('\nPlease see result.png\n')
avg_results = total_results / num_repeat

# plot result
plt.figure()
show_x = np.arange(0, Q, 10)
print avg_results[0]
print avg_results[1]
print avg_results[2]
#plt.plot(show_x, avg_results[::10, 0], '-bs', fillstyle='none', linewidth=1.5, markeredgewidth=1.5, label='UncertaintyMargin')
#plt.plot(show_x, avg_results[::10, 1], '-cv', fillstyle='none', linewidth=1.5, markeredgewidth=1.5, label='UncertaintyEntropy')
# plt.plot(show_x, avg_results[0], '-ro', fillstyle='none', linewidth=1.5, markeredgewidth=1.5, label='ALCE')
# plt.plot(show_x, avg_results[1], '-y^', fillstyle='none', linewidth=1.5, markeredgewidth=1.5, label='CWMM')
# plt.plot(show_x, avg_results[2], '-gd', fillstyle='none', linewidth=1.5, markeredgewidth=1.5, label='MEC')
# plt.xlabel('number of queries')
# plt.ylabel('average costs')
# plt.legend(loc='upper right')
# plt.savefig('result.png')
