import numpy as np
print(np.array([[0, 2], [4, 0]]))
        