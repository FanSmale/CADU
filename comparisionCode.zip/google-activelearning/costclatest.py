from sklearn.ensemble import RandomForestClassifier
from sklearn.cross_validation import train_test_split
from costcla.datasets import load_creditscoring1
from costcla.models import CostSensitiveDecisionTreeClassifier
from costcla.models import CostSensitiveLogisticRegression
from costcla.models import CostSensitiveRandomForestClassifier
from costcla.metrics import savings_score
import numpy as np
import sys
sys.path.append('/Users/wuyanxue/Desktop/google-activelearning')


dss = ['allaml', 'arcene', 'banana', 'credit6000', 'german', 'heart', 'ionosphere_real', 'jain', 'madelon', 'sonar', 'spambase', 'thyroid']
Qs = [10, 63, 602, 899, 93, 57, 50, 43, 628, 65, 413, 47]
ds = dss[0]
Q = Qs[0]
print(ds)
x_data = np.loadtxt('data/' + ds + '.x', dtype=float)
y_data = np.loadtxt('data/' + ds + '.y', dtype=int)
N = x_data.shape[0]
#false positives, false negatives, true positives and true negatives
cost_mat1 = np.array([2, 4, 0, 0])
cost_mat_all = np.array([[0, 4], [2, 0]])
cost_mat = np.repeat([cost_mat1], N, axis = 0)
results = np.zeros((1, ))
numRepeat = 1
for i in xrange(numRepeat):
    idx = np.arange(N)
    np.random.shuffle(idx) #Shuffle
    x_pool = x_data[idx]
    y_pool = y_data[idx]
    y_pool[y_pool == 2] = 0
    x_train = x_pool[:Q]
    y_train = y_pool[:Q]
    cost_mat_train = cost_mat[:Q]
    x_test = x_pool[Q:]
    y_test = y_pool[Q:]
    cost_mat_test = cost_mat[Q:]

    models = [CostSensitiveLogisticRegression()]
    for j in xrange(1):
        models[j].fit(x_train, y_train, cost_mat_train)
        pre = models[j].predict(x_test)
        results[j] += np.sum([cost_mat_all[y, int(p)] for y, p in zip(y_test, pre)]) + Q
    print('OK')

results /= (numRepeat * N)

print(results[0])


    
