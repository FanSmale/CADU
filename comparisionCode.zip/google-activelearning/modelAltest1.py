import numpy as np
from sklearn.decomposition import PCA
#from sklearn.datasets import load_iris
from modAL.models import ActiveLearner

from modAL.uncertainty import uncertainty_sampling
from modAL.uncertainty import margin_sampling
from modAL.uncertainty import entropy_sampling
from modAL.models import ActiveLearner, Committee
from modAL.disagreement import vote_entropy_sampling, consensus_entropy_sampling, max_disagreement_sampling
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
import sys

dss = ['allaml', 'arcene', 'banana', 'credit6000', 'german', 'heart', 'ionosphere_real', 'jain', 'madelon', 'sonar', 'spambase', 'thyroid']
Qs = [10, 63, 602, 899, 93, 57, 50, 43, 628, 65, 413, 47]

for k, ds in enumerate(dss):
    print(ds)
    Q = Qs[k] - 2

    cost_mat = np.array([[0, 4], [2, 0]]) # cost matrix
    result = 0
    numRepeat = 5
    for i in range(numRepeat):
    
        x_data = np.loadtxt('data/'+ds+'.x', dtype=float)
        y_data = np.loadtxt('data/'+ds+'.y', dtype=int)
        N = x_data.shape[0]
        idx = np.arange(N)
        np.random.shuffle(idx)
        x_data = x_data[idx]
        y_data = y_data[idx]
        #initial training data
        idx_lbl = np.zeros((y_data.shape[0], ), dtype=bool)
        idx_lbl[np.random.choice(np.where(y_data==1)[0])] = True
        idx_lbl[np.random.choice(np.where(y_data==2)[0])] = True
    
        X_train = x_data[idx_lbl]
        y_train = y_data[idx_lbl]

        # initializing the active learner
        learners = [
        # ActiveLearner(
        #     predictor=KNeighborsClassifier(n_neighbors=5),
        #     X_initial=X_train,
        #     y_initial=y_train
        # ),
        ActiveLearner(
            predictor=RandomForestClassifier(),
            X_initial=X_train, 
            y_initial=y_train
        ), ActiveLearner(
            predictor=DecisionTreeClassifier(),
            X_initial=X_train, 
            y_initial=y_train
        ), ActiveLearner(
            predictor=SVC(probability=True),
            X_initial=X_train, 
            y_initial=y_train
        )]

        committee = Committee(learner_list = learners, query_strategy = consensus_entropy_sampling)
 

        X_pool = x_data[idx_lbl == False]
        y_pool = y_data[idx_lbl == False]

        for idx in range(Q):
            query_idx, query_instance = committee.query(X_pool)
            committee.teach(
                X=X_pool[query_idx].reshape(1, -1),
                y=y_pool[query_idx].reshape(1, )
            )
            # remove queried instance from pool
            X_pool = np.delete(X_pool, query_idx, axis=0)
            y_pool = np.delete(y_pool, query_idx)


        result += np.sum([cost_mat[y-1, p-1] for y, p in zip(y_pool, committee.predict(X_pool))]) + Q + 2
    
    print(result / (numRepeat * N))



    