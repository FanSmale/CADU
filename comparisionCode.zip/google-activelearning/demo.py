# My demo for runing experiments

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import pickle
import sys
from time import gmtime
from time import strftime

import numpy as np
from sklearn.preprocessing import normalize
from sklearn.preprocessing import StandardScaler

from google.apputils import app
import gflags as flags
from tensorflow import gfile
from sampling_methods.margin_AL import MarginAL
from sampling_methods.informative_diverse import InformativeClusterDiverseSampler
from sampling_methods.hierarchical_clustering_AL import HierarchicalClusterAL
from sampling_methods.uniform_sampling import UniformSampling
#from sampling_methods.MarginAL1 import MarginAL

from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC

from utils import utils
sys.path.append('/Users/wuyanxue/Desktop/google-activelearning')

dss = ['allaml', 'arcene', 'banana', 'credit6000', 'german', 'heart', 'ionosphere_real', 'jain', 'madelon', 'sonar', 'spambase', 'thyroid']
steps = [1, 5, 30, 50, 5, 3, 3, 3, 40, 4, 25, 3]
numIterative = [20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]

ds = dss[0]
step = steps[0]
length = numIterative[0]
cost_mat = [[0, 4], [2, 0]]

print('data: ', ds)
print('step: ', str(step))
print('numExperiment: ', str(length))

# load data
x_data = np.loadtxt('data/'+ds+'.x', dtype=float)
y_data = np.loadtxt('data/'+ds+'.y', dtype=int)
N = x_data.shape[0]


idx = np.arange(N)
np.random.shuffle(idx)

x_pool = x_data[idx[:]]
y_pool = y_data[idx[:]]
# Already be selected
idx_lbl = np.zeros((N, ), dtype=bool)
for i in xrange(2):
	idx_lbl[np.random.choice(np.where(y_pool == (i + 1))[0])] = True

models = [MarginAL(x_pool[idx_lbl==False], y_pool[idx_lbl==False], 0), 
InformativeClusterDiverseSampler(x_pool[idx_lbl==False], y_pool[idx_lbl==False], 0), 
HierarchicalClusterAL(x_pool[idx_lbl==False], y_pool[idx_lbl==False], 0), 
UniformSampling(x_pool[idx_lbl==False], y_pool[idx_lbl==False], 0)]

results = np.zeros((len(models), length))

for j, model in enumerate(models):
    print(j)
    for i in xrange(length):
        
        select_batch_inputs = {
            "model": OneVsRestClassifier(SVC(probability=True)), 
            "already_selected": [],
            "N": (i+1)*step
        }
        
        select_inds = model.select_batch(**select_batch_inputs)
        print('ok', str(select_inds))
        clf = OneVsRestClassifier(SVC())
        clf.fit(x_pool[select_inds], y_pool[select_inds])
        unselected = [i for i in range(N) if i not in select_inds]
        predict = clf.predict(x_pool[unselected])
        results[j, i] =  np.sum([cost_mat[y - 1, p - 1] for y, p in zip(y_pool[unselected], predict)]) + (i + 1) * step + 2
        results[j, i] /= N
        print(np.sum([cost_mat[y - 1, p - 1] for y, p in zip(y_pool[unselected], predict)]) + (i + 1) * step + 2)

print(results)

print('OK')












